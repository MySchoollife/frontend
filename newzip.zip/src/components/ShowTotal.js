
const ShowTotal = (total) => {
    return (
        `Total ${total} Record(s)`
    );
};

export default ShowTotal;
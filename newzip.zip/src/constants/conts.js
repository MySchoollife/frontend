export const PRICE = "ZAR";

export const bannerType = [
    {id : 'normal', value : "Normal"},
    {id : 'category', value : "Category"},
    // {id : 'offer', value : "Offer"}
]
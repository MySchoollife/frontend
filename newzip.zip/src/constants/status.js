
export const ConnectStatus = {
    DEFAULT:'Connect',
    CONNECT: 'Connected',
    REMOVE: 'Remove',
    PENDING: 'Pending'
}
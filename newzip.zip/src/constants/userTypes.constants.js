export const UserTypes = {
  ADMIN: "Admin",
  SPECIALIST: "Specialist",
  DRIVER: "Driver",
  CUSTOMER: "Customer",
  DEALER: "Dealer",
  SUB_ADMIN: "SubAdmin",
  VENDOR: "Vendor",
};

export const adminId = "64c7366ec01fae98da0614b5";

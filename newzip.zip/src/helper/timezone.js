import moment from "moment";
import "moment-timezone";

export const Timezone = moment.tz.guess();

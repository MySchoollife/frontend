export const s3Config = (type) => ({
  dirName: "school/" + type,
  bucketName: "school",
  region: "us-east-2",
  accessKeyId: "AKIGBdgdfgdfgdMIAPJWKU5",
  secretAccessKey: "xEb3z6BdfsdfaJBAuhP4sfsdfsdfsdfb0ZRkmnUUg8fsdfs99Nsg7C",
});

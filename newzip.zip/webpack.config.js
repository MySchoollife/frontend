module.exports = {
    devtool: false,
};